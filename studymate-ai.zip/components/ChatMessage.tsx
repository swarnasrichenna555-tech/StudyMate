
import React from 'react';
import { Message } from '../types';
import { BotIcon } from './icons/BotIcon';
import { UserIcon } from './icons/UserIcon';

interface ChatMessageProps {
  message: Message;
  isLoading?: boolean;
}

export const ChatMessage: React.FC<ChatMessageProps> = ({ message, isLoading = false }) => {
  const isAi = message.sender === 'ai';

  return (
    <div className={`flex items-start gap-4 ${isAi ? '' : 'flex-row-reverse'}`}>
      <div className={`flex-shrink-0 w-10 h-10 rounded-full flex items-center justify-center ${isAi ? 'bg-sky-500' : 'bg-slate-600'}`}>
        {isAi ? <BotIcon className="w-6 h-6 text-white" /> : <UserIcon className="w-6 h-6 text-white" />}
      </div>
      <div className={`px-4 py-3 rounded-lg max-w-lg ${isAi ? 'bg-slate-700 text-slate-200 rounded-tl-none' : 'bg-sky-600 text-white rounded-tr-none'}`}>
        {isLoading ? (
            <div className="flex items-center space-x-1">
                <span className="w-2 h-2 bg-slate-400 rounded-full animate-pulse-fast"></span>
                <span className="w-2 h-2 bg-slate-400 rounded-full animate-pulse-medium"></span>
                <span className="w-2 h-2 bg-slate-400 rounded-full animate-pulse-slow"></span>
            </div>
        ) : (
          <p className="text-sm whitespace-pre-wrap">{message.text}</p>
        )}
      </div>
      <style>{`
        .animate-pulse-fast { animation: pulse 1s cubic-bezier(0.4, 0, 0.6, 1) infinite; }
        .animate-pulse-medium { animation: pulse 1s cubic-bezier(0.4, 0, 0.6, 1) infinite 0.2s; }
        .animate-pulse-slow { animation: pulse 1s cubic-bezier(0.4, 0, 0.6, 1) infinite 0.4s; }
        @keyframes pulse {
          0%, 100% { opacity: 1; }
          50% { opacity: .5; }
        }
      `}</style>
    </div>
  );
};
