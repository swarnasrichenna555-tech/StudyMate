
import React, { useState, useCallback } from 'react';
import { UploadIcon } from './icons/UploadIcon';
import { PdfIcon } from './icons/PdfIcon';

interface FileUploadProps {
  onFilesUpload: (files: File[]) => void;
  isProcessing: boolean;
}

export const FileUpload: React.FC<FileUploadProps> = ({ onFilesUpload, isProcessing }) => {
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
  const [isDragging, setIsDragging] = useState(false);

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (event.target.files) {
      const files = Array.from(event.target.files).filter(file => file.type === 'application/pdf');
      setSelectedFiles(files);
    }
  };

  const handleDrop = useCallback((event: React.DragEvent<HTMLDivElement>) => {
    event.preventDefault();
    event.stopPropagation();
    setIsDragging(false);
    if (event.dataTransfer.files && event.dataTransfer.files.length > 0) {
      const files = Array.from(event.dataTransfer.files).filter(file => file.type === 'application/pdf');
      setSelectedFiles(files);
      event.dataTransfer.clearData();
    }
  }, []);

  const handleDragOver = useCallback((event: React.DragEvent<HTMLDivElement>) => {
    event.preventDefault();
    event.stopPropagation();
  }, []);
  
  const handleDragEnter = useCallback((event: React.DragEvent<HTMLDivElement>) => {
    event.preventDefault();
    event.stopPropagation();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback((event: React.DragEvent<HTMLDivElement>) => {
    event.preventDefault();
    event.stopPropagation();
    setIsDragging(false);
  }, []);

  const handleSubmit = () => {
    if (selectedFiles.length > 0) {
      onFilesUpload(selectedFiles);
    }
  };

  return (
    <div className="w-full max-w-2xl mx-auto flex flex-col items-center justify-center p-8 bg-slate-800 rounded-xl shadow-2xl h-full border border-slate-700">
      <div 
        className={`w-full p-10 border-2 border-dashed rounded-lg text-center transition-colors duration-300 ${isDragging ? 'border-sky-400 bg-slate-700/50' : 'border-slate-600 hover:border-sky-500'}`}
        onDrop={handleDrop}
        onDragOver={handleDragOver}
        onDragEnter={handleDragEnter}
        onDragLeave={handleDragLeave}
      >
        <input
          type="file"
          id="file-upload"
          multiple
          accept=".pdf"
          onChange={handleFileChange}
          className="hidden"
        />
        <label htmlFor="file-upload" className="cursor-pointer flex flex-col items-center">
            <UploadIcon className="w-12 h-12 text-slate-500 mb-4" />
            <p className="text-slate-300">
              <span className="font-semibold text-sky-400">Click to upload</span> or drag and drop
            </p>
            <p className="text-xs text-slate-400 mt-1">PDF documents only</p>
        </label>
      </div>

      {selectedFiles.length > 0 && (
        <div className="w-full mt-6">
          <h3 className="text-lg font-semibold text-slate-200">Selected Files:</h3>
          <ul className="mt-2 space-y-2 max-h-40 overflow-y-auto pr-2">
            {selectedFiles.map((file, index) => (
              <li key={index} className="flex items-center bg-slate-700 p-2 rounded-md">
                <PdfIcon className="w-5 h-5 text-red-400 mr-3 flex-shrink-0"/>
                <span className="text-sm text-slate-300 truncate">{file.name}</span>
              </li>
            ))}
          </ul>
        </div>
      )}

      <div className="w-full mt-8">
        {isProcessing ? (
           <div className="flex items-center justify-center w-full bg-sky-500 text-white font-bold py-3 px-4 rounded-lg">
            <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
            </svg>
            Processing...
           </div>
        ) : (
          <button
            onClick={handleSubmit}
            disabled={selectedFiles.length === 0}
            className="w-full bg-sky-500 text-white font-bold py-3 px-4 rounded-lg transition-colors duration-200 enabled:hover:bg-sky-600 disabled:bg-slate-600 disabled:cursor-not-allowed"
          >
            Start Session
          </button>
        )}
         <p className="text-xs text-slate-500 mt-4 text-center">
            * For this demo, file content is simulated. The AI will respond based on pre-loaded text about React.
        </p>
      </div>
    </div>
  );
};
