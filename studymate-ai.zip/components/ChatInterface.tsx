
import React, { useState, useRef, useEffect } from 'react';
import { Message } from '../types';
import { ChatMessage } from './ChatMessage';
import { SendIcon } from './icons/SendIcon';
import { PdfIcon } from './icons/PdfIcon';

interface ChatInterfaceProps {
  messages: Message[];
  onSendMessage: (message: string) => void;
  isLoading: boolean;
  uploadedFiles: File[];
}

export const ChatInterface: React.FC<ChatInterfaceProps> = ({ messages, onSendMessage, isLoading, uploadedFiles }) => {
  const [input, setInput] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isLoading]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (input.trim()) {
      onSendMessage(input);
      setInput('');
    }
  };

  return (
    <div className="flex flex-col h-full bg-slate-800 rounded-xl shadow-2xl border border-slate-700 overflow-hidden">
        <div className="p-4 border-b border-slate-700">
            <h2 className="text-lg font-semibold text-slate-200">Conversation</h2>
            <div className="flex items-center space-x-2 mt-1 text-sm text-slate-400">
                <PdfIcon className="w-4 h-4 text-red-400" />
                <span>Active document: {uploadedFiles.map(f => f.name).join(', ')}</span>
            </div>
        </div>
        <div className="flex-grow p-4 overflow-y-auto">
            <div className="space-y-6">
            {messages.map((msg) => (
                <ChatMessage key={msg.id} message={msg} />
            ))}
            {isLoading && (
                 <ChatMessage key="loading" message={{id: 'loading', sender: 'ai', text: '...'}} isLoading={true} />
            )}
            <div ref={messagesEndRef} />
            </div>
        </div>
        <div className="p-4 border-t border-slate-700 bg-slate-800">
            <form onSubmit={handleSubmit} className="flex items-center space-x-2">
            <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Ask a question about your documents..."
                className="flex-grow bg-slate-700 text-slate-200 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-sky-500 border border-slate-600"
                disabled={isLoading}
            />
            <button
                type="submit"
                disabled={isLoading || !input.trim()}
                className="bg-sky-500 text-white p-2 rounded-full transition-colors duration-200 enabled:hover:bg-sky-600 disabled:bg-slate-600 disabled:cursor-not-allowed"
            >
                <SendIcon className="w-5 h-5" />
            </button>
            </form>
        </div>
    </div>
  );
};
