
import React, { useState, useEffect, useCallback } from 'react';
import { FileUpload } from './components/FileUpload';
import { ChatInterface } from './components/ChatInterface';
import { Message } from './types';
import { askQuestionAboutText } from './services/geminiService';

// Dummy text to simulate PDF extraction.
// In a real application, this would be dynamically extracted from the uploaded PDFs.
const SIMULATED_EXTRACTED_TEXT = `
React is a free and open-source front-end JavaScript library for building user interfaces based on components. It is maintained by Meta (formerly Facebook) and a community of individual developers and companies.

React can be used to develop single-page, mobile, or server-rendered applications with frameworks like Next.js. Because React is only concerned with the user interface and rendering components to the DOM, React applications often rely on libraries for routing and other client-side functionality.

A key advantage of React is that it only rerenders components that have changed, which can significantly improve performance. This is achieved through a virtual DOM. When the state of a component changes, React creates a new virtual DOM tree, compares it with the previous one (a process called "diffing"), and then updates the real DOM with only the necessary changes.

Components in React are typically written in JSX (JavaScript XML), a JavaScript syntax extension that allows embedding HTML-like code within JavaScript. Components can be class-based or function-based. Modern React development heavily favors function components with Hooks, which were introduced in React 16.8. Hooks like useState and useEffect allow function components to manage state and side effects.
`;


export default function App() {
  const [uploadedFiles, setUploadedFiles] = useState<File[]>([]);
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [extractedText, setExtractedText] = useState<string | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [isLoadingAnswer, setIsLoadingAnswer] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const handleFilesUpload = (files: File[]) => {
    setUploadedFiles(files);
    setMessages([]);
    setError(null);
  };

  useEffect(() => {
    if (uploadedFiles.length > 0) {
      setIsProcessing(true);
      // Simulate PDF text extraction process
      setTimeout(() => {
        setExtractedText(SIMULATED_EXTRACTED_TEXT);
        setIsProcessing(false);
        setMessages([
          {
            id: 'initial-ai-message',
            sender: 'ai',
            text: `I've finished reviewing your document(s). Ask me anything about their content.`,
          },
        ]);
      }, 2000);
    }
  }, [uploadedFiles]);

  const handleSendMessage = useCallback(async (question: string) => {
    if (!question.trim() || isLoadingAnswer || !extractedText) return;

    const userMessage: Message = { id: Date.now().toString(), sender: 'user', text: question };
    setMessages(prev => [...prev, userMessage]);
    setIsLoadingAnswer(true);
    setError(null);

    try {
      const answer = await askQuestionAboutText(extractedText, question);
      const aiMessage: Message = { id: (Date.now() + 1).toString(), sender: 'ai', text: answer };
      setMessages(prev => [...prev, aiMessage]);
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'An unexpected error occurred.';
      setError(`Sorry, I couldn't get an answer. ${errorMessage}`);
      const aiErrorMessage: Message = { 
        id: (Date.now() + 1).toString(), 
        sender: 'ai', 
        text: `I ran into a problem trying to answer that. Please try again. Error: ${errorMessage}` 
      };
      setMessages(prev => [...prev, aiErrorMessage]);
    } finally {
      setIsLoadingAnswer(false);
    }
  }, [isLoadingAnswer, extractedText]);
  
  const handleReset = () => {
    setUploadedFiles([]);
    setExtractedText(null);
    setMessages([]);
    setError(null);
    setIsLoadingAnswer(false);
    setIsProcessing(false);
  }

  return (
    <div className="bg-slate-900 text-white min-h-screen font-sans flex flex-col">
      <header className="w-full p-4 border-b border-slate-700 bg-slate-900/80 backdrop-blur-sm sticky top-0 z-10">
        <div className="max-w-4xl mx-auto flex justify-between items-center">
          <h1 className="text-2xl font-bold text-sky-400">StudyMate AI</h1>
          {extractedText && (
             <button 
                onClick={handleReset}
                className="bg-sky-500 hover:bg-sky-600 text-white font-bold py-2 px-4 rounded-lg transition-colors duration-200 text-sm"
             >
                Start New Session
            </button>
          )}
        </div>
      </header>

      <main className="flex-grow flex flex-col items-center justify-center p-4 w-full">
        <div className="w-full max-w-4xl h-full flex flex-col">
          {extractedText ? (
            <ChatInterface
              messages={messages}
              onSendMessage={handleSendMessage}
              isLoading={isLoadingAnswer}
              uploadedFiles={uploadedFiles}
            />
          ) : (
            <FileUpload 
              onFilesUpload={handleFilesUpload} 
              isProcessing={isProcessing}
            />
          )}
        </div>
      </main>
    </div>
  );
}
