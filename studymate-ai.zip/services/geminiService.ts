
import { GoogleGenAI } from "@google/genai";

if (!process.env.API_KEY) {
  throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export async function askQuestionAboutText(contextText: string, question: string): Promise<string> {
  const prompt = `
    You are an intelligent study assistant named StudyMate.
    Your task is to answer questions based *only* on the provided text context.
    Do not use any external knowledge or information you have outside of this context.
    If the answer is not found within the provided text, you must explicitly state: "I could not find an answer in the provided document(s)."
    Analyze the following text and answer the user's question.

    --- CONTEXT ---
    ${contextText}
    --- END CONTEXT ---

    User's Question: ${question}
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });
    return response.text;
  } catch (error) {
    console.error("Error calling Gemini API:", error);
    if (error instanceof Error) {
        return `An error occurred while communicating with the AI: ${error.message}`;
    }
    return "An unknown error occurred while communicating with the AI.";
  }
}
